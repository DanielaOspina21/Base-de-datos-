<header class="mb-auto">
    <div>
      <h3 class="float-md-start mb-0">Cover</h3>
      <nav class="nav nav-masthead justify-content-center float-md-end">
        <a class="nav-link fw-bold py-1 px-0 active" aria-current="page" href="MOSTRAR.php">CONSULTAR MASCOTAS</a>
        <a class="nav-link fw-bold py-1 px-0 active" href="REGISTRO_DE_MASCOTA.php">REGISTRAR MASCOTA</a>
        <a class="nav-link fw-bold py-1 px-0 active" href="ELIMINAR.php">ELIMINAR MASCOTAS</a>
        <a class="nav-link fw-bold py-1 px-0 active" href="ACTUALIZAR.php">ACTUALIZAR MASCOTA</a>
      </nav>
    </div>
  </header>