<?php

require_once "../confi/conex.php";

$id = $_POST["id"];

$sql = "DELETE FROM animales WHERE id = " .$id. ""; 


if($dbh->query($sql))
{
    echo "eliminado" ;
}else
{ 
    echo"no eliminado" ;
}




?>