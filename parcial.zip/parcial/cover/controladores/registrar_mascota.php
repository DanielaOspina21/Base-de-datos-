<?php
require "../confi/conex.php";

$dueno = $_POST ["dueno"];
$nombre = $_POST ["nombre"];

$sql = "INSERT INTO animales(fecha_sys, nombre, dueno)
VALUES
(now(),'".$nombre."','".$dueno."')" ;
if($dbh->query($sql))
{
    echo "bien" ;
}else
{ 
    echo"mal" ;
}




