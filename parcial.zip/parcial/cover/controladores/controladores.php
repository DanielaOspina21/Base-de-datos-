<?php
if (isset($_POST['calculate'])) {
    $first_number = $_POST['first_number'];
    $second_number = $_POST['second_number'];
    $operator = $_POST['operator'];

    switch ($operator) {
        case 'add':
            $result = $first_number + $second_number;
            break;
        case 'subtract':
            $result = $first_number - $second_number;
            break;
        case 'multiply':
            $result = $first_number * $second_number;
            break;
        case 'divide':
            $result = $second_number != 0 ? $first_number / $second_number : 'Error: Division by zero';
            break;
        default:
            $result = 0;
    }
}

if (isset($_POST['register'])) {
    $nombre = htmlspecialchars($_POST['nombre']);
    $documento = htmlspecialchars($_POST['documento']);
    $edad = (int)$_POST['edad'];

    $errors = [];

    if (empty($nombre)) {
        $errors[] = "El nombre es obligatorio.";
    }

    if (empty($documento)) {
        $errors[] = "El documento es obligatorio.";
    }

    if ($edad < 18) {
        $errors[] = "Error: Debes ser mayor de edad para registrarte.";
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo "<div class='alert alert-danger'>$error</div>";
        }
    } else {
        echo "Registro exitoso. ¡Bienvenido, $nombre!";
    }
}
if (isset($_POST['register_sale'])) {
    $valor_producto = (float)$_POST['valor_producto'];
    $descripcion_venta = htmlspecialchars($_POST['descripcion_venta']);
    
    $errors = [];

    if ($valor_producto <= 0) {
        $errors[] = "El valor del producto debe ser mayor que cero.";
    }

    if (empty($descripcion_venta)) {
        $errors[] = "La descripción de la venta es obligatoria.";
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo "<div class='alert alert-danger'>$error</div>";
        }
    } else {
        echo "Venta registrada exitosamente. Valor: $valor_producto, Descripcion: $descripcion_venta";
    }
}


if (isset($_POST['votaciones'])) 
    
    
$candidatos = ['Candidato 1', 'Candidato 2', 'Candidato 3'];


if (!isset($_SESSION['votos'])) {
    $_SESSION['votos'] = [0, 0, 0];  
}


if (!isset($_SESSION['voto_realizado'])) {
    
    if (isset($_POST['votacion'])) {
        $voto = (int)$_POST['votacion']; 
        if ($voto >= 0 && $voto < 3) {
            $_SESSION['votos'][$voto]++; 
            $_SESSION['voto_realizado'] = true; 
        }
    }
}


function obtenerGanador($votos) {
    $max_votos = max($votos);  
    $index_ganador = array_search($max_votos, $votos);  
    return [$GLOBALS['candidatos'][$index_ganador], $max_votos];  
}

list($ganador, $votos_ganador) = obtenerGanador($_SESSION['votos']);
?>



